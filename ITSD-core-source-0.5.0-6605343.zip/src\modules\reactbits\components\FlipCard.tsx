// FlipCard: written for itsd, not downloaded from React Bits (the registry has no FlipCard that fits a slide).
// It follows the same conventions as the downloaded components: default export, props with defaults, a sibling .css and .meta.json.
// Content is split at `+++` lines by the deck (meta.json: "parts": true), so children arrive as [front, back].
import { Children, useRef, useState, type CSSProperties, type FocusEvent, type KeyboardEvent, type MouseEvent, type ReactNode } from 'react';
import './FlipCard.css';

interface FlipCardProps {
  children?: ReactNode;
  className?: string;
  trigger?: 'click' | 'hover';
  direction?: 'horizontal' | 'vertical';
  duration?: number;
  perspective?: number;
  borderRadius?: number;
  frontBackground?: string;
  backBackground?: string;
  borderColor?: string;
  flipped?: boolean;
}

// Clicks that belong to what is on the card (editor, Run button, links) must not flip it.
const INTERACTIVE = '.run, .monaco-editor, button, a, input, textarea, select, [contenteditable="true"]';

const FlipCard: React.FC<FlipCardProps> = ({
  children,
  className = '',
  trigger = 'click',
  direction = 'horizontal',
  duration = 0.7,
  perspective = 1200,
  borderRadius = 16,
  frontBackground = '#151a2d',
  backBackground = '#1d2340',
  borderColor = 'rgb(255 255 255 / 14%)',
  flipped: startFlipped = false,
}) => {
  const [flipped, setFlipped] = useState(startFlipped);
  const live = useRef({ pointer: false, focus: false });
  const faces = Children.toArray(children);
  const front = faces[0] ?? null;
  const back = faces.length > 1 ? faces.slice(1) : <div className="flip-empty">Add the back with a +++ line</div>;
  const hover = trigger === 'hover';
  const axis = direction === 'vertical' ? 'v' : 'h';

  const onClick = (e: MouseEvent<HTMLDivElement>) => {
    if (hover || (e.target as HTMLElement).closest(INTERACTIVE)) return;
    setFlipped((f) => !f);
  };
  // Space/Enter flip only when the card itself has focus; inside the editor they are just typing.
  const onKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.target !== e.currentTarget || (e.key !== 'Enter' && e.key !== ' ')) return;
    e.preventDefault(); setFlipped((f) => !f);
  };
  // Hover mode: pointer-in flips, pointer-out flips back, unless focus is inside (someone is typing in the code on the back).
  const onEnter = () => { live.current.pointer = true; if (hover) setFlipped(true); };
  const onLeave = () => { live.current.pointer = false; if (hover && !live.current.focus) setFlipped(false); };
  const onFocus = () => { live.current.focus = true; };
  const onBlur = (e: FocusEvent<HTMLDivElement>) => {
    if (e.currentTarget.contains(e.relatedTarget as Node | null)) return;
    live.current.focus = false;
    if (hover && !live.current.pointer) setFlipped(false);
  };

  const flip = (e: MouseEvent) => { e.stopPropagation(); setFlipped((f) => !f); };
  const btn = !hover && <button type="button" className="flip-btn" aria-label="Flip card" title="Flip" onClick={flip}>↻</button>;

  return (
    <div
      className={`flip-card ${axis}${flipped ? ' flipped' : ''} ${className}`.trim()}
      style={{
        '--fc-persp': `${perspective}px`, '--fc-dur': `${duration}s`, '--fc-radius': `${borderRadius}px`,
        '--fc-front': frontBackground, '--fc-back': backBackground, '--fc-border': borderColor,
      } as CSSProperties}
      tabIndex={0}
      role="group"
      aria-roledescription="flip card"
      onClick={onClick} onKeyDown={onKeyDown}
      onPointerEnter={onEnter} onPointerLeave={onLeave} onFocus={onFocus} onBlur={onBlur}
    >
      <div className="flip-inner">
        {/* Both faces always stay in layout (visibility, never display:none) so an editor on the hidden side keeps its size. */}
        <div className={`flip-face front ${axis}${flipped ? ' off' : ''}`} aria-hidden={flipped}>{btn}{front}</div>
        <div className={`flip-face back ${axis}${flipped ? '' : ' off'}`} aria-hidden={!flipped}>{btn}{back}</div>
      </div>
    </div>
  );
};

export default FlipCard;
